<?php

namespace Alura\DesignPattern;

class Orcamento
{
    public float $valor;
}
