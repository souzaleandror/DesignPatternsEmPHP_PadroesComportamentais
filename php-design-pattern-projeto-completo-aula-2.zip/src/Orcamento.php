<?php

namespace Alura\DesignPattern;

class Orcamento
{
    public int $quantidadeItens;
    public float $valor;
}
